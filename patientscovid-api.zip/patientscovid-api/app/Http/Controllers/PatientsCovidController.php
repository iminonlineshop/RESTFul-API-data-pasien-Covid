<?php

namespace App\Http\Controllers;

use App\Models\Patients;
use Illuminate\Http\Request;

class PatientsCovidController extends Controller
{
   function index() {
    $patients = Patients::all();

    if (count($patients)){
        $data = [
           'message'=> "Get All Resource",
           'data'=> $patients
        ];
       return response()->json($data, 200);
       } else {
           $data = [
               'message' => "Data is empty"
           ];
           return response()->json($data, 200);
        }
   }

   public function store(Request $request) {
    $validateData = $request->validate([
        'name' => 'required',
        'phone' =>  'numeric|required' ,
        'address' => 'required',
        'status' => 'required',
        'in_date_at' => ' date | required ',
        'out_date_at' => 'nullable'
    ]);
    $patients = Patients::create($validateData);
    $data = [
        'message' => 'Resource is added successfully',
        'data' => $patients
    ];

    return response()->json($data, 201);
   }

   public function show($id) {
    $patients = Patients::find($id);

    if ($patients) {
        $data = [
            'message' => 'Get Detail Resource',
            'data' => $patients
        ];

        return response()->json($data, 200);
    } else {
        $data = [
            'message' => "Resource not found"
        ];

        return response()->json($data, 404);
    }
   }

   public function update($id , Request $request) {
    $patients = Patients::find($id);

    if ($patients) {
        $input = [
            'name' => $request->name ?? $patients->name,
            'phone' => $request->phone ?? $patients->phone,
            'address' => $request->address ?? $patients->address,
            'status' => $request->status ?? $patients->status,
            'in_date_at' => $request->in_date_at ?? $patients->in_date_at,
            'out_date_at' => $request->out_date_at ?? $patients->out_date_at
        ];

        $patients->update($input);

        $data = [
            'message' => 'Resource is update successfully',
            'data' => $patients
        ];

        return response()->json($data, 201);
        $data = [
            'message' => "Resource not found"
        ];

        return response()->json($data, 404);
    }
   }

   function destroy($id) {
    $patients =  Patients::find($id);

        if ($patients) {
            # hapus patient tersebut
            $patients->delete();

            $data = [
                'message' => "Resource is delete successfully"
            ];

            # mengembalikan pesan dan kode 200
            return response()->json($data, 200);
        } else {
            $data = [
                'message' => "Resource not found"
            ];

            # mengembalikan pesan dan kode 404
            return response()->json($data, 404);
        }

        //postive
        function positive(){
            $patients = Patients::where('status', 'positive')->get();
            $data = [
                'message' => "Get postive resource",
                'total' => count($patients),
                'data'=> $patients
            ];
            return response()->json($data, 200);
        }

        //recovered
        function recovered(){
            $patient = Patients::where('status', 'recovered')->get();
            $data = [
                'message' => "Get recovered resource",
                'total' => (count($patient)),
                'data'=> $patient
            ];
            return response()->json($data, 200);
        }
        //recovered
        function dead($status){
            $patient = Patients::where($status);
            $data = [
                'message' => "Get dead resource",
                'total' => (count($patient)),
                'data'=> $patient
            ];
            return response()->json($data, 200);
        }
    }
}